﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpecflowAutomation.Pages
{
   public class InstallationPage: BasePage
    {
        private static InstallationPage installationPage;
        public static InstallationPage Instance => installationPage ?? (installationPage = new InstallationPage());
    }
}
