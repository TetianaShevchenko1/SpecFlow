﻿using OpenQA.Selenium;
using System.Linq;

namespace SpecflowAutomation.Pages
{
    public class SpecFlowPage: BasePage
    {
        private string SearchFieldXpath => "//input[@name = 'q']";
        private string SearchResultXpath => ".//h2[@class='search__result__title']";

        private static SpecFlowPage specFlowPage;
        public static SpecFlowPage Instance => specFlowPage ?? (specFlowPage = new SpecFlowPage());

        public void ClickSearchField()
        {
            var searchField = FindElement(By.XPath(SearchFieldXpath));
            searchField.Click();
        }

        public void ClickResultOfSearch(string item)
        {
            var result = FindElements(By.XPath(SearchResultXpath)).First(x => x.Text.Equals(item));
            result.Click();
        }

        public void SetTextInSearchField(string text)
        {
            var searchField = FindElement(By.XPath(SearchFieldXpath));
            searchField.SendKeys(text);
        }
    }
}
