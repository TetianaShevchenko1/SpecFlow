﻿using NUnit.Framework;
using SpecflowAutomation.Pages;
using SpeckflowAutomation.Base;
using System.Threading;
using TechTalk.SpecFlow;

namespace SpecflowAutomation.Steps
{
    [Binding]
    public sealed class MainMenuSteps
    {
        // For additional details on SpecFlow step definitions see https://go.specflow.org/doc-stepdef

        private readonly ScenarioContext _scenarioContext;

        public MainMenuSteps(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [Given(@"I open official Specflow web site")]
        public void OpenOfficialSpecflowWebSite()
        {
            HomePage.Instance.OpenSpecFlowHomePage();
        }

        [When(@"I hover the '(.*)' menu item from the main menu")]
        public void HoverTheMenuItemFromTheMainMenu(string menuItem)
        {
            Thread.Sleep(2000);
            HomePage.Instance.HoverMainMenuItem(menuItem);
        }

        [When(@"I click '(.*)' option from the main menu")]
        public void ClickOptionFromTheMainMenu(string option)
        {
            HomePage.Instance.ClickSubMenuItem(option);
        }

        [When(@"I click on '(.*)' field")]
        public void ClickOnField()
        {
            SpecFlowPage.Instance.ClickSearchField();
        }

        [When(@"I typing text '(.*)'")]
        public void TypingText(string text)
        {
            SpecFlowPage.Instance.SetTextInSearchField(text);
        }

        [When(@"I click result of search '(.*)'")]
        public void ClickResultOfSearch(string result)
        {
           SpecFlowPage.Instance.ClickResultOfSearch(result);
        }

        [Then(@"Page with '(.*)' title should be opened")]
        public void PageWithTitleShouldBeOpened(string title)
        {
            Assert.IsTrue(BasePage.Instance.IsPageTitleDisplayed(title), "Page title for the page is not displayed");
        }

        [AfterScenario]
        public static void AfterTestRun()
        {
            DriverManager.QuitDriver();
        }
    }
}
